"""ZOMBO test suite."""
